# proteus_python_simulator_png
image of elctronics compornent in  proteus 
![Screenshot (12)](https://github.com/kenn2018/Electronic_voting_validating_machine/assets/40261217/8d20a6be-a110-40ac-a623-c835e83f945e)
